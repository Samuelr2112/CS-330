
///////////////////////////////////////////////////////////////////////////////
// maincode.cpp
// ============
// gets called when application is launched - initializes GLEW, GLFW
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Updated by Samuel Rincon for CS-330-Computational Graphics and Visualization
///////////////////////////////////////////////////////////////////////////////

#include <iostream>         // error handling and output
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include "GLFW/glfw3.h"     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Image loading with stb_image
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

// Namespace for declaring global variables
namespace
{
    const char* const WINDOW_TITLE = "7-1 FinalProject and Milestones";

    GLFWwindow* g_Window = nullptr;

    SceneManager* g_SceneManager = nullptr;
    ShaderManager* g_ShaderManager = nullptr;
    ViewManager* g_ViewManager = nullptr;

    GLuint texture1, texture2;

    // Function to load texture using stb_image
    GLuint loadTexture(const char* texturePath)
    {
        GLuint textureID;
        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        // Texture parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        // Load image
        int width, height, nrChannels;
        unsigned char* data = stbi_load(texturePath, &width, &height, &nrChannels, 0);
        if (data)
        {
            GLenum format = nrChannels == 3 ? GL_RGB : GL_RGBA;
            glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
            glGenerateMipmap(GL_TEXTURE_2D);
            std::cout << "Successfully loaded texture: " << texturePath << std::endl;
        }
        else
        {
            std::cerr << "Failed to load texture: " << texturePath << std::endl;
        }
        stbi_image_free(data);

        return textureID;
    }

    void initTextures()
    {
        // Load both textures (using the paths for the textures we added)
        texture1 = loadTexture("shaders/sample_texture_1.jpg");
        texture2 = loadTexture("shaders/sample_texture_2.jpg");
    }

    void renderScene()
    {
        // Bind the textures before drawing the corresponding objects
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture1);

        // Draw your first textured object here (Ensure you have texture coordinates)
        // (Example: some cube or 3D object using texture1)

        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, texture2);

        // Draw your second textured object here
        // (Example: ground or another object using texture2)
    }

    // Function to set texture coordinates and update objects
    void setupTextureCoordinates()
    {
        // Example setup for texture coordinates if using a cube:
        float cubeVertices[] = {
            // positions          // texture coords
            -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
             0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
             0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
             0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
            -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
            -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
            // more vertices can be added here for other faces
        };

        // Code to bind and set up VAO/VBO for your 3D objects can be added here
    }

}

int main()
{
    // Initialization code

    initTextures();
    setupTextureCoordinates();

    while (!glfwWindowShouldClose(g_Window))
    {
        // Render loop
        renderScene();
        glfwSwapBuffers(g_Window);
        glfwPollEvents();
    }

    // Cleanup and close the window
    glfwTerminate();
    return 0;
}
